from django.apps import AppConfig


class CandidateapplicationConfig(AppConfig):
    name = 'candidateapplication'
